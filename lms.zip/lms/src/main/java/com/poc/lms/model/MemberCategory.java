package com.poc.lms.model;

public enum MemberCategory {
 STUDENT,EMPLOYEE,RETIRED,OTHERS
}
