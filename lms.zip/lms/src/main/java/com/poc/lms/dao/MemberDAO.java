package com.poc.lms.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.lms.model.Member;
import com.poc.lms.repository.MemberRepository;


public interface MemberDAO {
	public Member save(Member member);
	
}
