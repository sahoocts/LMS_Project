package com.poc.lms.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotBlank;

public class Course {


	@Id
	@Column(name="course_Id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long courseId;
	
	@NotBlank
	@Column(name= "course_name")
	private String coursename;
	
	
	@ManyToMany
	private Set<Member> members;	
	
	public long getCourseId() {
		return courseId;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public Set<Member> getMembers() {
		return members;
	}

	public void setMembers(Set<Member> members) {
		this.members = members;
	}

}
