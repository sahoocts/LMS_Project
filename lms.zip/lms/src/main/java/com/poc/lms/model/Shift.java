package com.poc.lms.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class Shift {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Shift_Id")
	private long Id;
	@Column(name = "shart_shift")
	private String shartshift;
	@Column(name = "end_shift")
	private String endshift;
	@OneToOne
	@JoinColumn(name = "Member_Id")
	private Member member;

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getShartshift() {
		return shartshift;
	}

	public void setShartshift(String shartshift) {
		this.shartshift = shartshift;
	}

	public String getEndshift() {
		return endshift;
	}

	public void setEndshift(String endshift) {
		this.endshift = endshift;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

}
