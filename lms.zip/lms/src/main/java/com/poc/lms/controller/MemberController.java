package com.poc.lms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.lms.dao.MemberDAO;
import com.poc.lms.dao.MemberDaoImpl;
import com.poc.lms.model.Member;


@RestController
@RequestMapping("/company")
public class MemberController {

	@Autowired
	MemberDaoImpl memberDaoImpl;
	@PostMapping("/members")
	public Member createMember(@Valid @RequestBody Member member){
		return memberDaoImpl.save(member);
		//return memberDaoImpl.save(member);
	}
}
